"""Performance summary + automatic PS requirement checks."""
from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import config


@dataclass
class PerformanceSummary:
    frames_processed: int
    duration_s: float
    fps: float
    acquisition_time_s: float | None
    average_tracking_error_px: float
    maximum_tracking_error_px: float
    rmse_tracking_error_px: float
    average_centroid_error_px: float
    maximum_centroid_error_px: float
    lock_retention_percentage: float
    target_loss_percentage: float
    target_loss_events: int
    successful_reacquisitions: int
    average_reacquisition_time_s: float | None
    average_processing_time_ms: float
    max_processing_time_ms: float
    ground_truth_available: bool
    source: str
    maximum_reacquisition_time_s: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


def evaluate_ps_requirements(summary: PerformanceSummary) -> dict[str, Any]:
    """Evaluate the five measurable PS performance limits.

    A requirement with unavailable evidence is marked ``PENDING`` rather than
    being incorrectly treated as a pass. Target-loss uses the strict PS
    requirement ``< 5%``; processing speed uses sustained measured FPS.
    """
    checks: dict[str, dict[str, Any]] = {}

    acq = summary.acquisition_time_s
    checks["acquisition_time"] = {
        "requirement": "<= 2.0 s",
        "value": acq,
        "status": "PENDING" if acq is None else ("PASS" if acq <= config.PS_ACQUISITION_MAX_S else "FAIL"),
    }

    max_err = float(summary.maximum_tracking_error_px)
    checks["tracking_error"] = {
        "requirement": "<= 10 px",
        "value": max_err,
        "status": "PASS" if max_err <= config.PS_TRACKING_ERROR_MAX_PX else "FAIL",
    }

    loss = float(summary.target_loss_percentage)
    checks["target_loss"] = {
        "requirement": "< 5%",
        "value": loss,
        "status": "PASS" if loss < config.PS_TARGET_LOSS_MAX_PERCENT else "FAIL",
    }

    reacq = summary.maximum_reacquisition_time_s
    if reacq is None:
        reacq = summary.average_reacquisition_time_s
    checks["reacquisition_time"] = {
        "requirement": "<= 1.0 s",
        "value": reacq,
        "status": "PENDING" if reacq is None else ("PASS" if reacq <= config.PS_REACQUISITION_MAX_S else "FAIL"),
        "basis": "maximum observed" if summary.maximum_reacquisition_time_s is not None else "average observed",
    }

    fps = float(summary.fps)
    checks["processing_speed"] = {
        "requirement": ">= 20 FPS",
        "value": fps,
        "status": "PASS" if fps >= config.PS_PROCESSING_MIN_FPS else "FAIL",
    }

    statuses = [item["status"] for item in checks.values()]
    overall = "FAIL" if "FAIL" in statuses else ("PENDING" if "PENDING" in statuses else "PASS")
    return {"overall": overall, "checks": checks}


def save_performance_report(summary: PerformanceSummary, output_dir="reports", prefix="performance"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    data = asdict(summary)
    data["ps_requirement_check"] = evaluate_ps_requirements(summary)
    data["generated_utc"] = datetime.now(timezone.utc).isoformat()

    json_path = out / f"{prefix}_{stamp}.json"
    csv_path = out / f"{prefix}_{stamp}.csv"

    json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Metric", "Value"])
        for key, value in data.items():
            if isinstance(value, dict):
                value = json.dumps(value, sort_keys=True)
            writer.writerow([key, value])

    return json_path, csv_path
