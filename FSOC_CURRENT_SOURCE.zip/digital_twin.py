from __future__ import annotations

import math
import random
from collections import deque
from typing import Iterable

from PySide6.QtCore import QPoint, QPointF, Qt, QRectF
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QBrush, QPolygonF, QRadialGradient
from PySide6.QtWidgets import QHBoxLayout, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget

import config


class DigitalTwinWidget(QWidget):
    """Independent-view 3D-style space visualization of the live FSOC state.

    The viewer is NOT aligned to the optical camera POV.  User yaw/pitch/zoom
    controls are independent of PAT pan/tilt.  Satellite positions come from
    the same simulator frame used by the radar and virtual-camera feed.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(900, 600)
        self.setFocusPolicy(Qt.StrongFocus)

        self.camera_angles = (0.0, 0.0)
        self.target_angles = (0.0, 0.0)
        self.predicted_angles = None
        self.range_m = 1000.0
        self.targets: list[dict] = []
        self.world_targets: list[dict] = []
        self.camera_position = (0.0, 0.0, 0.0)
        self.designated_id = "TGT-01"
        self.state = "SEARCHING"
        self.frame_count = 0
        self.sim_time = 0.0
        self.fps = 0.0
        self.motion_pattern = "Straight Line"
        self.turbulence_enabled = False
        self.turbulence_strength = 0.0
        self.jitter_enabled = False
        self.jitter_strength = 0.0
        self.platform_enabled = False
        self.platform_strength = 0.0
        self.noise_name = "None"
        self.atmosphere_name = "Clear"
        self.atmosphere_level = 0
        self.platform_offset_px = (0.0, 0.0)
        self.jitter_px = (0.0, 0.0)
        self.beam_wander_px = (0.0, 0.0)
        self.link_ready = False

        # Independent user view: these values are never overwritten by PAT pan/tilt.
        self.view_yaw = -38.0
        self.view_pitch = 16.0
        self.zoom = 1.05
        self._dragging = False
        self._last_mouse = QPoint()

        rng = random.Random(26169)
        self._stars = []
        for _ in range(1100):
            z = rng.uniform(20.0, 105.0)
            x = rng.uniform(-55.0, 55.0)
            y = rng.uniform(-36.0, 36.0)
            b = rng.uniform(0.25, 1.0)
            tint = rng.choice(("white", "white", "white", "cool", "warm"))
            self._stars.append((x, y, z, b, tint))

        self._celestial = [
            {"name": "EARTH", "pos": (-41.0, -20.0, 112.0), "r": 7.0, "kind": "earth"},
            {"name": "MOON", "pos": (27.0, 18.0, 118.0), "r": 1.55, "kind": "moon"},
            {"name": "SUN", "pos": (82.0, -38.0, 176.0), "r": 3.6, "kind": "sun"},
        ]

        # Deterministic procedural Earth surface detail. This is a visual
        # context model, not a geographic map; no weather is rendered.
        earth_rng = random.Random(1969)
        self._earth_land = []
        for _ in range(9):
            cx = earth_rng.uniform(-0.48, 0.46)
            cy = earth_rng.uniform(-0.42, 0.42)
            rx = earth_rng.uniform(0.08, 0.22)
            ry = earth_rng.uniform(0.045, 0.13)
            self._earth_land.append((cx, cy, rx, ry, earth_rng.uniform(-0.25, 0.25)))

        self._target_trails: dict[str, deque[tuple[float, float, float]]] = {}
        self._camera_trail: deque[tuple[float, float, float]] = deque(maxlen=100)

    # --------------------------- state/synchronization ---------------------------
    def set_state(
        self,
        *,
        camera_angles,
        target_angles,
        predicted_angles=None,
        range_m=1000.0,
        targets: Iterable[dict] | None = None,
        world_targets: Iterable[dict] | None = None,
        camera_position=(0.0, 0.0, 0.0),
        designated_id="TGT-01",
        state="SEARCHING",
        frame_count=0,
        sim_time=0.0,
        fps=0.0,
        motion_pattern="Straight Line",
        turbulence_enabled=False,
        turbulence_strength=0.0,
        jitter_enabled=False,
        jitter_strength=0.0,
        platform_enabled=False,
        platform_strength=0.0,
        noise_name="None",
        atmosphere_name="Clear",
        atmosphere_level=0,
        platform_offset_px=(0.0, 0.0),
        jitter_px=(0.0, 0.0),
        beam_wander_px=(0.0, 0.0),
        link_ready=False,
    ):
        self.camera_angles = (float(camera_angles[0]), float(camera_angles[1]))
        self.target_angles = (float(target_angles[0]), float(target_angles[1]))
        self.predicted_angles = None if predicted_angles is None else (float(predicted_angles[0]), float(predicted_angles[1]))
        self.range_m = float(range_m)
        self.world_targets = [dict(item) for item in (world_targets or targets or [])]
        self.targets = [dict(item) for item in (targets or self.world_targets)]
        self.camera_position = tuple(float(v) for v in camera_position)
        self.designated_id = str(designated_id)
        self.state = str(state)
        self.frame_count = int(frame_count)
        self.sim_time = float(sim_time)
        self.fps = float(fps)
        self.motion_pattern = str(motion_pattern)
        self.turbulence_enabled = bool(turbulence_enabled)
        self.turbulence_strength = float(turbulence_strength)
        self.jitter_enabled = bool(jitter_enabled)
        self.jitter_strength = float(jitter_strength)
        self.platform_enabled = bool(platform_enabled)
        self.platform_strength = float(platform_strength)
        self.noise_name = str(noise_name)
        self.atmosphere_name = str(atmosphere_name)
        self.atmosphere_level = int(atmosphere_level)
        self.platform_offset_px = tuple(float(v) for v in platform_offset_px)
        self.jitter_px = tuple(float(v) for v in jitter_px)
        self.beam_wander_px = tuple(float(v) for v in beam_wander_px)
        self.link_ready = bool(link_ready)

        for t in self.world_targets:
            tid = str(t.get("id", ""))
            if not tid:
                continue
            pos = self._world_position_from_raw(t)
            self._target_trails.setdefault(tid, deque(maxlen=70)).append(pos)
        self._camera_trail.append(self.camera_position)
        self.update()

    # ------------------------------ 3D projection --------------------------------
    def _rotate_view(self, p):
        x, y, z = p
        yaw = math.radians(self.view_yaw)
        pitch = math.radians(self.view_pitch)
        cy, sy = math.cos(yaw), math.sin(yaw)
        x1 = x * cy - z * sy
        z1 = x * sy + z * cy
        cp, sp = math.cos(pitch), math.sin(pitch)
        y2 = y * cp - z1 * sp
        z2 = y * sp + z1 * cp
        return x1, y2, z2

    def _project(self, p):
        x, y, z = self._rotate_view(p)
        depth = max(0.65, z + 64.0)
        scale = min(self.width(), self.height()) * 1.18 * self.zoom
        sx = self.width() * 0.50 + x * scale / depth
        sy = self.height() * 0.52 - y * scale / depth
        return QPointF(sx, sy), depth

    def _world_position_from_raw(self, target):
        # Local inertial visualization coordinates derived directly from the
        # simulator's raw target trajectory. This preserves selected movement
        # shape without making the 3D viewport follow the optical camera.
        x = float(target.get("x", config.FRAME_WIDTH / 2.0))
        y = float(target.get("y", config.FRAME_HEIGHT / 2.0))
        rng_m = float(target.get("range_m", self.range_m))
        wx = (x - config.FRAME_WIDTH / 2.0) / 14.5
        wy = (config.FRAME_HEIGHT / 2.0 - y) / 13.0
        wz = 8.5 + max(-2.5, min(3.5, (rng_m - 1000.0) / 260.0))
        return (wx, wy, wz)

    def _projected_prediction(self, world_targets):
        designated = next((t for t in world_targets if str(t.get("id")) == self.designated_id), None)
        if designated is None or self.predicted_angles is None:
            return None
        # Small forward prediction in local world space, using Kalman angular
        # lead only as an offset from the actual target. It does not change the
        # underlying target motion.
        pp, pt = self.predicted_angles
        tx, ty = self.camera_angles
        dx = (pp - tx) / max(config.FOV_HORIZONTAL, 0.1) * 4.8
        dy = -(pt - ty) / max(config.FOV_VERTICAL, 0.1) * 4.2
        p = self._world_position_from_raw(designated)
        return (p[0] + dx * 0.16, p[1] + dy * 0.16, p[2])

    # ----------------------------- environment rendering ------------------------
    def _draw_background(self, painter):
        rect = self.rect()
        painter.fillRect(rect, QColor(0, 1, 4))

        grad = QRadialGradient(rect.center(), max(rect.width(), rect.height()) * 0.92)
        grad.setColorAt(0.0, QColor(8, 17, 31))
        grad.setColorAt(0.46, QColor(2, 8, 17))
        grad.setColorAt(1.0, QColor(0, 1, 4))
        painter.fillRect(rect, QBrush(grad))

        # Very faint galactic dust band for depth. It is intentionally subtle
        # so stars remain discrete rather than becoming a space "effect".
        painter.save()
        painter.setOpacity(0.035)
        painter.setPen(QPen(QColor(180, 205, 235), 56))
        painter.drawArc(
            QRectF(-280, self.height() * 0.18, self.width() + 560, self.height() * 0.90),
            8 * 16,
            168 * 16,
        )
        painter.restore()

    def _draw_starfield(self, painter):
        for x, y, z, brightness, tint in self._stars:
            p, depth = self._project((x, y, z))
            if not (-4 <= p.x() <= self.width() + 4 and -4 <= p.y() <= self.height() + 4):
                continue
            radius = 0.55 + 1.45 * brightness * max(0.38, min(1.25, 46.0 / depth))
            alpha = int(70 + 170 * brightness)
            if tint == "cool":
                c = QColor(182, 218, 255, alpha)
            elif tint == "warm":
                c = QColor(255, 225, 195, alpha)
            else:
                c = QColor(238, 244, 250, alpha)
            painter.setPen(QPen(c, radius))
            painter.drawPoint(p)

    def _draw_celestial_body(self, painter, body):
        p, depth = self._project(body["pos"])
        base_scale = min(self.width(), self.height()) * self.zoom / max(depth, 1.0)
        radius = max(2.0, body["r"] * base_scale)
        if p.x() < -radius * 1.4 or p.x() > self.width() + radius * 1.4 or p.y() < -radius * 1.4 or p.y() > self.height() + radius * 1.4:
            return

        kind = body["kind"]
        if kind == "sun":
            # Distant sun disc + restrained halo; no flare animation.
            glow = QRadialGradient(p, radius * 3.8)
            glow.setColorAt(0.0, QColor(255, 235, 174, 155))
            glow.setColorAt(0.28, QColor(255, 216, 120, 72))
            glow.setColorAt(1.0, QColor(255, 190, 80, 0))
            painter.setBrush(QBrush(glow))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(p, radius * 3.8, radius * 3.8)
            disk = QRadialGradient(p - QPointF(radius * 0.28, radius * 0.28), radius * 1.15)
            disk.setColorAt(0.0, QColor(255, 250, 221, 250))
            disk.setColorAt(0.65, QColor(255, 228, 150, 245))
            disk.setColorAt(1.0, QColor(222, 169, 75, 230))
            painter.setBrush(QBrush(disk))
            painter.setPen(QPen(QColor(255, 241, 188, 180), 0.7))
            painter.drawEllipse(p, radius, radius)
            painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
            painter.setPen(QColor(244, 214, 150, 180))
            painter.drawText(int(p.x() + radius + 5), int(p.y() + 2), "SUN")
            return

        if kind == "earth":
            # Procedural shaded Earth with an atmospheric rim and a few land
            # masses. No clouds/fog/rain are rendered in this space view.
            light = QRadialGradient(p - QPointF(radius * 0.28, radius * 0.24), radius * 1.15)
            light.setColorAt(0.0, QColor(83, 164, 213, 245))
            light.setColorAt(0.58, QColor(33, 93, 149, 245))
            light.setColorAt(1.0, QColor(5, 21, 45, 255))
            painter.setBrush(QBrush(light))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(p, radius, radius)

            # Night-side city glow, only as sparse points on the dark limb.
            painter.save()
            painter.setClipRegion(painter.clipRegion())
            for fracx, fracy in [(-0.48, 0.18), (-0.30, 0.34), (0.08, 0.40), (0.26, 0.18), (0.42, -0.04), (-0.02, -0.24)]:
                cx = p.x() + fracx * radius
                cy = p.y() + fracy * radius
                if (cx - p.x()) ** 2 + (cy - p.y()) ** 2 < (0.86 * radius) ** 2:
                    painter.setPen(QPen(QColor(255, 201, 112, 110), max(1.0, radius * 0.013)))
                    painter.drawPoint(QPointF(cx, cy))
            painter.restore()

            painter.save()
            painter.setOpacity(0.72)
            painter.setPen(QPen(QColor(81, 148, 115, 150), max(0.7, radius * 0.014)))
            for cx, cy, rx, ry, rot in self._earth_land:
                center = QPointF(p.x() + cx * radius, p.y() + cy * radius)
                painter.save()
                painter.translate(center)
                painter.rotate(math.degrees(rot))
                painter.drawEllipse(QRectF(-rx * radius, -ry * radius, 2 * rx * radius, 2 * ry * radius))
                painter.restore()
            painter.restore()

            rim = QRadialGradient(p, radius * 1.08)
            rim.setColorAt(0.82, QColor(120, 215, 245, 0))
            rim.setColorAt(0.96, QColor(128, 218, 255, 100))
            rim.setColorAt(1.0, QColor(128, 218, 255, 20))
            painter.setBrush(QBrush(rim))
            painter.setPen(QPen(QColor(140, 226, 255, 150), max(0.7, radius * 0.012)))
            painter.drawEllipse(p, radius * 1.02, radius * 1.02)
        else:
            light = QRadialGradient(p - QPointF(radius * 0.25, radius * 0.25), radius * 1.12)
            light.setColorAt(0.0, QColor(208, 213, 220, 230))
            light.setColorAt(0.64, QColor(130, 137, 148, 220))
            light.setColorAt(1.0, QColor(50, 55, 64, 240))
            painter.setBrush(QBrush(light))
            painter.setPen(QPen(QColor(210, 218, 225, 150), max(0.6, radius * 0.02)))
            painter.drawEllipse(p, radius, radius)
            for crater_x, crater_y, crater_r in [(-0.22, -0.12, 0.09), (0.18, 0.21, 0.065), (0.35, -0.18, 0.05)]:
                painter.setBrush(QBrush(QColor(72, 76, 84, 85)))
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(QPointF(p.x() + crater_x * radius, p.y() + crater_y * radius), radius * crater_r, radius * crater_r)

        painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
        painter.setPen(QColor(184, 204, 216, 160))
        painter.drawText(int(p.x() + radius + 5), int(p.y() + 2), body["name"])

    # ----------------------------- spacecraft drawing ---------------------------
    def _draw_satellite(self, painter, pos, name, designated=False, camera_unit=False):
        p, depth = self._project(pos)
        scale = min(self.width(), self.height()) * self.zoom / max(depth, 1.0)
        body_w = max(18.0, 22.0 * scale / 34.0)
        body_h = max(10.0, 13.0 * scale / 34.0)

        # Main spacecraft bus. Faceted silhouette gives a better 3D read than a box.
        body = QPolygonF([
            QPointF(p.x() - body_w, p.y() - body_h * 0.55),
            QPointF(p.x() - body_w * 0.32, p.y() - body_h),
            QPointF(p.x() + body_w * 0.96, p.y() - body_h * 0.64),
            QPointF(p.x() + body_w, p.y() + body_h * 0.62),
            QPointF(p.x() - body_w * 0.52, p.y() + body_h),
        ])
        painter.setBrush(QBrush(QColor(55, 66, 75, 248)))
        painter.setPen(QPen(QColor(181, 195, 207, 222), 1.0))
        painter.drawPolygon(body)

        # Thermal/radiator face.
        painter.setBrush(QBrush(QColor(28, 35, 43, 245)))
        painter.setPen(QPen(QColor(104, 123, 138, 170), 0.8))
        painter.drawPolygon(QPolygonF([
            QPointF(p.x() - body_w * 0.98, p.y() - body_h * 0.47),
            QPointF(p.x() - body_w * 0.54, p.y() - body_h * 0.78),
            QPointF(p.x() - body_w * 0.54, p.y() + body_h * 0.78),
            QPointF(p.x() - body_w * 0.98, p.y() + body_h * 0.47),
        ]))

        # Solar arrays with cell strips.
        for side in (-1, 1):
            x0 = p.x() + side * body_w * 1.02
            panel = QPolygonF([
                QPointF(x0, p.y() - body_h * 0.74),
                QPointF(x0 + side * body_w * 2.05, p.y() - body_h * 0.54),
                QPointF(x0 + side * body_w * 2.05, p.y() + body_h * 0.54),
                QPointF(x0, p.y() + body_h * 0.74),
            ])
            painter.setBrush(QBrush(QColor(13, 29, 50, 245)))
            painter.setPen(QPen(QColor(75, 128, 169, 225), 0.9))
            painter.drawPolygon(panel)
            for i in range(1, 5):
                frac = i / 5.0
                xx = x0 + side * body_w * 2.05 * frac
                painter.setPen(QPen(QColor(74, 119, 151, 150), 0.5))
                painter.drawLine(QPointF(xx, p.y() - body_h * 0.56), QPointF(xx, p.y() + body_h * 0.56))
            for frac in (-0.33, 0.0, 0.33):
                painter.setPen(QPen(QColor(89, 147, 180, 115), 0.45))
                painter.drawLine(
                    QPointF(x0 + side * body_w * 0.18, p.y() + frac * body_h),
                    QPointF(x0 + side * body_w * 1.92, p.y() + frac * body_h),
                )

        # Small attitude-control / star-tracker details.
        painter.setPen(QPen(QColor(208, 216, 222, 150), 0.7))
        painter.drawLine(QPointF(p.x(), p.y() - body_h), QPointF(p.x(), p.y() - body_h * 1.45))
        painter.setBrush(QBrush(QColor(175, 186, 192, 210)))
        painter.drawEllipse(QPointF(p.x(), p.y() - body_h * 1.55), 1.5, 1.5)

        if camera_unit:
            # Optical terminal on a small gimbal.
            gimbal_c = QPointF(p.x() + body_w * 1.02, p.y())
            painter.setPen(QPen(QColor(104, 143, 158, 190), 1.0))
            painter.setBrush(QBrush(QColor(19, 30, 38, 250)))
            painter.drawEllipse(gimbal_c, max(7.0, body_w * 0.58), max(7.0, body_w * 0.58))
            lens = QPointF(gimbal_c.x() + body_w * 0.18, gimbal_c.y())
            painter.setBrush(QBrush(QColor(5, 11, 18, 255)))
            painter.setPen(QPen(QColor(108, 217, 243, 220), 1.1))
            painter.drawEllipse(lens, max(4.0, body_w * 0.34), max(4.0, body_w * 0.34))
            painter.setBrush(QBrush(QColor(175, 245, 255, 235)))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(lens, max(1.4, body_w * 0.10), max(1.4, body_w * 0.10))

            # A small high-gain antenna on the rear.
            dish = QPointF(p.x() - body_w * 1.15, p.y() - body_h * 1.0)
            painter.setPen(QPen(QColor(158, 170, 181, 190), 0.8))
            painter.setBrush(QBrush(QColor(37, 48, 57, 235)))
            painter.drawEllipse(dish, max(3.5, body_w * 0.34), max(2.5, body_w * 0.24))

        if designated:
            beacon = QPointF(p.x(), p.y() - body_h * 1.78)
            pulse = 1.0 + 0.15 * math.sin(self.frame_count * 0.24)
            r = max(6.5, body_w * 0.45) * pulse
            glow = QRadialGradient(beacon, r * 4.5)
            glow.setColorAt(0.0, QColor(48, 255, 112, 220))
            glow.setColorAt(0.28, QColor(44, 255, 100, 105))
            glow.setColorAt(1.0, QColor(45, 255, 100, 0))
            painter.setBrush(QBrush(glow))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(beacon, r * 4.5, r * 4.5)
            painter.setBrush(QBrush(QColor(68, 255, 125, 255)))
            painter.setPen(QPen(QColor(219, 255, 228, 245), 1.0))
            painter.drawEllipse(beacon, r, r)
            painter.setPen(QPen(QColor(126, 255, 169, 120), 0.9))
            painter.drawEllipse(beacon, r * 1.7, r * 1.7)

        label_w = max(170, len(name) * 6.2 + 22)
        label_rect = QRectF(p.x() - label_w * 0.5, p.y() + body_h * 1.72, label_w, 24)
        painter.setBrush(QBrush(QColor(2, 8, 14, 238)))
        painter.setPen(QPen(QColor(70, 96, 111, 205), 0.8))
        painter.drawRoundedRect(label_rect, 6, 6)
        painter.setFont(QFont("Segoe UI", 7, QFont.Bold))
        painter.setPen(QColor(240, 247, 251))
        painter.drawText(label_rect, Qt.AlignCenter, name)
        return p

    def _draw_trail(self, painter, trail, color):
        pts = list(trail)
        if len(pts) < 2:
            return
        for i in range(1, len(pts)):
            p1, _ = self._project(pts[i - 1])
            p2, _ = self._project(pts[i])
            alpha = int(25 + 145 * i / len(pts))
            painter.setPen(QPen(QColor(*color, alpha), 1.3))
            painter.drawLine(p1, p2)

    def _draw_beam(self, painter, camera_world, target_world):
        cp, _ = self._project(camera_world)
        tp, _ = self._project(target_world)
        dx = tp.x() - cp.x()
        dy = tp.y() - cp.y()
        length = math.hypot(dx, dy)
        if length < 2.0:
            return
        ux, uy = dx / length, dy / length
        px, py = -uy, ux

        # Bright green visualization of the optical path.
        for width, alpha in ((15.0, 18), (9.0, 35), (4.0, 75)):
            painter.setPen(QPen(QColor(55, 255, 120, alpha), width))
            painter.drawLine(cp, tp)
        painter.setPen(QPen(QColor(165, 255, 188, 245), 1.3))
        painter.drawLine(cp, tp)

        # Visible beam-wander signature, driven by the actual turbulence sample.
        wx, wy = self.beam_wander_px
        if self.turbulence_enabled and (abs(wx) + abs(wy)) > 0.15:
            amp = min(20.0, 1.4 + 0.32 * math.hypot(wx, wy) + 0.10 * self.turbulence_strength)
            phase = self.frame_count * 0.46
            previous = None
            for i in range(31):
                t = i / 30.0
                wobble = math.sin(t * 10.0 + phase) * amp + math.sin(t * 23.0 - phase * 0.8) * amp * 0.28
                q = QPointF(cp.x() + dx * t + px * wobble, cp.y() + dy * t + py * wobble)
                if previous is not None:
                    painter.setPen(QPen(QColor(255, 215, 86, 175), 1.2, Qt.DashLine))
                    painter.drawLine(previous, q)
                previous = q

        # Direction ticks.
        painter.setPen(QPen(QColor(190, 255, 205, 175), 1.0))
        for t in (0.22, 0.50, 0.78):
            cx, cy = cp.x() + dx * t, cp.y() + dy * t
            tick = 4.5
            painter.drawLine(QPointF(cx - px * tick, cy - py * tick), QPointF(cx + px * tick, cy + py * tick))

    def _draw_pointer_axes(self, painter, camera_world, target_world):
        cp, _ = self._project(camera_world)
        tp, _ = self._project(target_world)
        dx, dy = tp.x() - cp.x(), tp.y() - cp.y()
        length = max(1.0, math.hypot(dx, dy))
        ux, uy = dx / length, dy / length
        # Short axis showing where the communication terminal is aiming in the independent view.
        a1 = QPointF(cp.x() + ux * 46, cp.y() + uy * 46)
        painter.setPen(QPen(QColor(85, 188, 242, 200), 1.4, Qt.DashLine))
        painter.drawLine(cp, a1)
        painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
        painter.setPen(QColor(107, 197, 241, 220))
        painter.drawText(int(a1.x() + 7), int(a1.y() - 5), "OPTICAL AXIS")

    def _draw_motion_vector(self, painter, trail, current_pos, label):
        pts = list(trail) if trail else []
        if len(pts) < 8:
            return
        previous = pts[-8]
        p1, _ = self._project(previous)
        p2, _ = self._project(current_pos)
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag = math.hypot(dx, dy)
        if mag < 1.0:
            return
        ux, uy = dx / mag, dy / mag
        px, py = -uy, ux
        arrow_len = min(34.0, mag * 0.65)
        base = QPointF(p2.x() - ux * arrow_len, p2.y() - uy * arrow_len)
        left = QPointF(p2.x() - ux * 8 + px * 4.5, p2.y() - uy * 8 + py * 4.5)
        right = QPointF(p2.x() - ux * 8 - px * 4.5, p2.y() - uy * 8 - py * 4.5)
        painter.setPen(QPen(QColor(91, 255, 150, 205), 1.8))
        painter.drawLine(base, p2)
        painter.setBrush(QBrush(QColor(91, 255, 150, 210)))
        painter.setPen(Qt.NoPen)
        painter.drawPolygon(QPolygonF([p2, left, right]))
        painter.setPen(QColor(116, 255, 160, 220))
        painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
        painter.drawText(int(base.x() + 6), int(base.y() - 7), label)

    def _draw_disturbance_markers(self, painter, camera_world, target_world):
        cp, _ = self._project(camera_world)
        tp, _ = self._project(target_world)

        if self.platform_enabled and self.platform_strength > 0:
            # Platform displacement arrow from nominal origin.
            px, py = self.platform_offset_px
            scale = 0.75
            ref = QPointF(cp.x() - px * scale, cp.y() + py * scale)
            painter.setPen(QPen(QColor(255, 114, 136, 190), 1.4, Qt.DashLine))
            painter.drawLine(ref, cp)
            painter.setBrush(QBrush(QColor(255, 114, 136, 180)))
            painter.drawEllipse(ref, 3.0, 3.0)
            painter.setPen(QColor(255, 140, 156, 225))
            painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
            painter.drawText(int(cp.x() + 10), int(cp.y() + 18), "PLATFORM MOTION")

        if self.jitter_enabled and self.jitter_strength > 0:
            # Camera vibration envelope.
            for i in range(4):
                rr = 18 + i * 7 + 2.5 * math.sin(self.frame_count * 0.75 + i)
                painter.setPen(QPen(QColor(255, 207, 84, 120 - i * 16), 1.0))
                painter.drawEllipse(cp, rr, rr * 0.72)
            painter.setPen(QColor(255, 219, 100, 220))
            painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
            painter.drawText(int(cp.x() + 10), int(cp.y() + 34), "CAMERA JITTER")

        if self.turbulence_enabled and self.turbulence_strength > 0:
            wx, wy = self.beam_wander_px
            end = QPointF(tp.x() + wx * 0.9, tp.y() - wy * 0.9)
            painter.setPen(QPen(QColor(255, 205, 70, 185), 1.2, Qt.DashLine))
            painter.drawLine(tp, end)
            painter.setBrush(QBrush(QColor(255, 205, 70, 180)))
            painter.drawEllipse(end, 3.0, 3.0)
            painter.setPen(QColor(255, 218, 102, 220))
            painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
            painter.drawText(int(tp.x() + 9), int(tp.y() + 22), "BEAM WANDER")

    # ---------------------------------- HUD --------------------------------------
    def _draw_hud(self, painter):
        w, h = self.width(), self.height()
        state_color = QColor(70, 255, 125) if self.state in {"TRACKING", "RE-ACQUIRING", "PREDICTING"} else QColor(255, 204, 80)
        painter.setFont(QFont("Segoe UI", 10, QFont.Bold))
        painter.setPen(state_color)
        painter.drawText(18, 26, f"● LIVE  |  FSOC 3D DIGITAL TWIN  |  PAT: {self.state}")
        painter.setFont(QFont("Segoe UI", 7))
        painter.setPen(QColor(173, 194, 208))
        painter.drawText(18, 43, f"t = {self.sim_time:06.2f} s   •   frame {self.frame_count:05d}   •   motion: {self.motion_pattern.upper()}")

        painter.setPen(QColor(112, 218, 160))
        painter.setFont(QFont("Segoe UI", 7, QFont.Bold))
        painter.drawText(max(20, w - 310), 26, "LOCAL INERTIAL VIEW  •  USER CONTROLLED")
        painter.setPen(QColor(150, 172, 185))
        painter.setFont(QFont("Segoe UI", 6))
        painter.drawText(max(20, w - 310), 42, "mouse drag: orbit   •   wheel: zoom   •   F11: full screen")
        painter.setPen(QColor(120, 145, 160, 190))
        painter.setFont(QFont("Segoe UI", 6))
        painter.drawText(max(20, w - 310), 56, f"VIEW YAW {self.view_yaw:+.1f}°  |  VIEW PITCH {self.view_pitch:+.1f}°  |  ZOOM {self.zoom:.2f}×")

        box_h = 112
        box = QRectF(14, h - box_h - 14, w - 28, box_h)
        painter.setBrush(QBrush(QColor(3, 10, 16, 236)))
        painter.setPen(QPen(QColor(44, 67, 80, 190), 1))
        painter.drawRoundedRect(box, 9, 9)

        painter.setFont(QFont("Segoe UI", 7, QFont.Bold))
        painter.setPen(QColor(237, 244, 248))
        painter.drawText(27, h - box_h + 4, f"TARGET  {self.designated_id}   •   {self.motion_pattern.upper()}   •   RANGE {self.range_m:.0f} m")
        painter.setPen(QColor(116, 255, 155))
        painter.drawText(27, h - box_h + 23, "BRIGHT BEACON  •  DESIGNATED COMMUNICATION TARGET")

        disturbance = []
        if self.platform_enabled and self.platform_strength > 0:
            disturbance.append(f"PLATFORM ±{self.platform_strength:.0f}px")
        if self.jitter_enabled and self.jitter_strength > 0:
            disturbance.append(f"JITTER ±{self.jitter_strength:.0f}px")
        if self.turbulence_enabled and self.turbulence_strength > 0:
            disturbance.append(f"BEAM-WANDER MODEL ±{self.turbulence_strength:.0f}px")
        if self.noise_name != "None":
            disturbance.append(f"SENSOR NOISE {self.noise_name}")
        dist_text = "  •  ".join(disturbance) if disturbance else "NOMINAL — NO ACTIVE DISTURBANCES"
        painter.setPen(QColor(246, 205, 92) if disturbance else QColor(144, 170, 183))
        painter.drawText(27, h - box_h + 42, f"DISTURBANCE STATE  •  {dist_text}")
        painter.setPen(QColor(135, 158, 171))
        painter.setFont(QFont("Segoe UI", 6))
        painter.drawText(27, h - box_h + 60, "ATMOSPHERIC RAIN / FOG / HAZE ARE NOT RENDERED IN THE TWO-SATELLITE SPACE SCENE")
        painter.drawText(27, h - box_h + 77, "GREEN BEAM IS A VISUALIZATION OF THE OPTICAL LINK PATH  •  VIEW IS NOT THE CAMERA POV")

        ready_text = "HANDOFF READY" if self.link_ready else "ALIGNMENT IN PROGRESS"
        ready_color = QColor(80, 255, 125) if self.link_ready else QColor(255, 198, 80)
        painter.setPen(ready_color)
        painter.setFont(QFont("Segoe UI", 8, QFont.Bold))
        painter.drawText(w - 190, h - 44, ready_text)
        painter.setPen(QColor(116, 143, 156))
        painter.setFont(QFont("Segoe UI", 6))
        painter.drawText(w - 190, h - 27, "coarse optical handoff")

    # ---------------------------------- paint ------------------------------------
    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        self._draw_background(painter)
        self._draw_starfield(painter)
        for body in self._celestial:
            self._draw_celestial_body(painter, body)

        # Draw current synchronized camera and target in a fixed local inertial frame.
        camera_world = self.camera_position
        entries = []
        for target in self.world_targets:
            tid = str(target.get("id", ""))
            pos = self._world_position_from_raw(target)
            entries.append((tid, bool(target.get("visible", True)), pos, tid == self.designated_id, float(target.get("range_m", self.range_m))))
        entries.sort(key=lambda item: sum(v * v for v in item[2]), reverse=True)

        # Trails / motion are deliberately prominent.
        for tid, visible, pos, designated, _r in entries:
            trail = self._target_trails.get(tid)
            if trail:
                self._draw_trail(painter, trail, (72, 255, 130) if designated else (128, 152, 168))

        self._draw_trail(painter, self._camera_trail, (90, 180, 238))

        designated_pos = None
        for tid, visible, pos, designated, _r in entries:
            self._draw_satellite(
                painter,
                pos,
                name=f"{tid}  •  {'BRIGHT BEACON' if designated else 'DECOY / OTHER TARGET'}",
                designated=designated,
                camera_unit=False,
            )
            if designated and visible:
                designated_pos = pos

        self._draw_satellite(
            painter,
            camera_world,
            name="TRACKING SATELLITE  •  CAMERA / OPTICAL TERMINAL",
            designated=False,
            camera_unit=True,
        )

        if designated_pos is not None:
            # Engineering line-of-sight and range cue.
            cp_screen, _ = self._project(camera_world)
            tp_screen, _ = self._project(designated_pos)
            painter.setPen(QPen(QColor(84, 177, 218, 90), 0.8, Qt.DotLine))
            painter.drawLine(cp_screen, tp_screen)

            self._draw_beam(painter, camera_world, designated_pos)
            self._draw_pointer_axes(painter, camera_world, designated_pos)
            self._draw_motion_vector(
                painter,
                self._target_trails.get(self.designated_id),
                designated_pos,
                f"VELOCITY VECTOR • {self.motion_pattern.upper()}",
            )
            self._draw_disturbance_markers(painter, camera_world, designated_pos)

            # Big, readable motion vector at the beacon.
            trail = self._target_trails.get(self.designated_id)
            if trail and len(trail) >= 6:
                old = list(trail)[-6]
                op, _ = self._project(old)
                tp, _ = self._project(designated_pos)
                painter.setPen(QPen(QColor(92, 255, 145, 170), 2.0, Qt.DashLine))
                painter.drawLine(op, tp)
                painter.setFont(QFont("Segoe UI", 7, QFont.Bold))
                painter.setPen(QColor(102, 255, 150, 225))
                painter.drawText(int(tp.x() + 10), int(tp.y() - 12), f"TARGET MOTION • {self.motion_pattern.upper()}")

            # Disturbance motion rings around camera platform.
            cp, _ = self._project(camera_world)
            if self.platform_enabled and self.platform_strength > 0:
                r = 15 + min(12, self.platform_strength * 0.45)
                painter.setPen(QPen(QColor(255, 112, 135, 160), 1.1))
                painter.drawEllipse(cp, r, r * 0.72)
            if self.jitter_enabled and self.jitter_strength > 0:
                for i in range(4):
                    r = 17 + i * 7 + 2 * math.sin(self.frame_count * 0.7 + i)
                    painter.setPen(QPen(QColor(255, 207, 80, 115 - i * 15), 1.0))
                    painter.drawEllipse(cp, r, r)

            pred = self._projected_prediction(self.world_targets)
            if pred is not None:
                pp, _ = self._project(pred)
                painter.setPen(QPen(QColor(255, 220, 84, 195), 1.3, Qt.DashLine))
                painter.drawLine(tp, pp)
                painter.setBrush(QBrush(QColor(255, 220, 84, 225)))
                painter.setPen(QPen(QColor(255, 235, 145), 1.2))
                painter.drawEllipse(pp, 6.0, 6.0)
                painter.setFont(QFont("Segoe UI", 6, QFont.Bold))
                painter.setPen(QColor(255, 223, 96, 235))
                painter.drawText(int(pp.x() + 9), int(pp.y() - 5), "KALMAN PREDICTION")

        self._draw_hud(painter)
        painter.end()

    # -------------------------------- interaction --------------------------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._last_mouse = event.position().toPoint()
            self.setFocus()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging:
            now = event.position().toPoint()
            dx = now.x() - self._last_mouse.x()
            dy = now.y() - self._last_mouse.y()
            self.view_yaw += dx * 0.40
            self.view_pitch += dy * 0.28
            self.view_pitch = max(-70.0, min(70.0, self.view_pitch))
            self._last_mouse = now
            self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def wheelEvent(self, event):
        steps = event.angleDelta().y() / 120.0
        self.zoom *= 1.0 + 0.12 * steps
        self.zoom = max(0.55, min(3.8, self.zoom))
        self.update()
        event.accept()

    def mouseDoubleClickEvent(self, event):
        window = self.window()
        if hasattr(window, "toggle_fullscreen"):
            window.toggle_fullscreen()
        else:
            window.showNormal() if window.isFullScreen() else window.showFullScreen()
        event.accept()


class DigitalTwinWindow(QMainWindow):
    """Standalone independent-view 3D scene synchronized to the main GUI."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FSOC — 3D Digital Twin | Independent Inertial View")
        self.resize(1320, 860)
        self.setMinimumSize(980, 700)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        bar = QHBoxLayout()
        title = QLabel("3D DIGITAL TWIN  •  SYNCHRONIZED TWO-SATELLITE SPACE SCENE")
        title.setStyleSheet("font-size: 11px; font-weight: 800; color: #dbe8f0; letter-spacing: 1px;")
        bar.addWidget(title)
        bar.addStretch()
        vacuum = QLabel("LOCAL INERTIAL VIEW  •  NO RAIN / FOG / HAZE")
        vacuum.setStyleSheet("font-size: 8px; font-weight: 700; color: #76d5a1;")
        bar.addWidget(vacuum)
        self.full_button = QPushButton("FULL SCREEN  F11")
        self.full_button.clicked.connect(self.toggle_fullscreen)
        self.full_button.setMinimumWidth(140)
        bar.addWidget(self.full_button)
        reset_button = QPushButton("RESET VIEW")
        reset_button.clicked.connect(self.reset_view)
        reset_button.setMinimumWidth(105)
        bar.addWidget(reset_button)
        layout.addLayout(bar)

        self.twin = DigitalTwinWidget(root)
        layout.addWidget(self.twin, 1)
        self.setCentralWidget(root)
        self._last_normal_geometry = None
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #010509; }
            QPushButton {
                background: #0b1822; border: 1px solid #284556; border-radius: 6px;
                padding: 7px 10px; color: #dbe8f0; font-weight: 700; font-size: 9px;
            }
            QPushButton:hover { background: #123043; }
        """)

    def set_state(self, **kwargs):
        self.twin.set_state(**kwargs)

    def reset_view(self):
        self.twin.view_yaw = -38.0
        self.twin.view_pitch = 16.0
        self.twin.zoom = 1.05
        self.twin.update()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            if self._last_normal_geometry is not None:
                self.setGeometry(self._last_normal_geometry)
            self.full_button.setText("FULL SCREEN  F11")
        else:
            self._last_normal_geometry = self.geometry()
            self.showFullScreen()
            self.full_button.setText("EXIT FULL SCREEN")

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F11:
            self.toggle_fullscreen()
            event.accept()
            return
        super().keyPressEvent(event)
